import java.util.Scanner;

public class Desafio1 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int tamanho;
		
		System.out.print("Insira at� qual n�mero ir� o array: ");
		tamanho = teclado.nextInt();
		
		int[] array = new int[tamanho];
		
		for(int i = 0; i < tamanho; i++) {
			array[i] = (i + 1);
		}
		
		for(int i = 0; i < tamanho; i = i + 2) {
			System.out.print(array[i] + "  ");
		}
	}

}

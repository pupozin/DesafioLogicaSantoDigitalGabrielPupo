import java.util.Scanner;

public class Desafio2 {

	public static void main(String[] args) {
		Scanner teclado = new Scanner(System.in);
		
		int posicao;
		int proximo = 1, anterior = 0, atual = 1;
		int valor1;
		
		System.out.print("Insira a posi��o do n�mero na sequ�ncia de fibonacci: ");
		posicao = teclado.nextInt();
		
		int[] numero = new int [posicao-1];
		
		if (posicao == 1) {
			System.out.println();
			System.out.println("O n�mero 1 �: 1");
			System.out.println();
			System.out.println("Possui somente um d�gito");
		} else {
		for(int i = 0; i < posicao - 1; i++) {
			numero[i] = proximo;
			anterior = atual + proximo;
			atual = proximo;
			proximo = anterior;
		}
		System.out.println();
		
		if (posicao < 7) {
			System.out.println("O numero " + posicao + " �: " + numero[posicao - 2] );
			System.out.println();
			System.out.println("O n�mero possui somente um d�gito.");
		} else {
		System.out.println("O numero " + posicao + " �: " + numero[posicao - 2] );
		
		System.out.println();
		
		valor1 = numero[posicao - 2] % 100;
		
		System.out.println("Dois ultimos digitos: " + valor1);
		}
		}
		
	}
 
}
